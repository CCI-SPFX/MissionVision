import { Version } from "@microsoft/sp-core-library";
import { IPropertyPaneConfiguration } from "@microsoft/sp-property-pane";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
export interface IMissionVisionWebPartProps {
    listName: string;
    gridBackground: string;
    gridGap: string;
    itemAsLink: boolean;
    itemWidth: string;
    itemBackground: string;
    iconWidth: string;
    titleFontSize: string;
    descFontSize: string;
    alignment: string;
}
export default class MissionVisionWebPart extends BaseClientSideWebPart<IMissionVisionWebPartProps> {
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected onInit(): Promise<void>;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=MissionVisionWebPart.d.ts.map
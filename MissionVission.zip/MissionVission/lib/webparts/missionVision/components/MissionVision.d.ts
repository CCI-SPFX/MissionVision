import * as React from 'react';
import { IMissionVisionProps } from './IMissionVisionProps';
import "./style.css";
declare const MissionVision: React.FunctionComponent<IMissionVisionProps>;
export default MissionVision;
//# sourceMappingURL=MissionVision.d.ts.map
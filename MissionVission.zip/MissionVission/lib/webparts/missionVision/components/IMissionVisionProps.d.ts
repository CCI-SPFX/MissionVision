import { SPHttpClient } from '@microsoft/sp-http';
export interface IMissionVisionProps {
    listName: string;
    siteUrl: string;
    spHttpClient: SPHttpClient;
    alignment: string;
    gridBackground: string;
    gridGap: string;
    itemAsLink: boolean;
    itemWidth: string;
    itemBackground: string;
    iconWidth: string;
    titleFontSize: string;
    descFontSize: string;
}
export interface IGridItem {
    id: number;
    title: string;
    description: string;
    url: string;
    iconUrl: string;
}
//# sourceMappingURL=IMissionVisionProps.d.ts.map
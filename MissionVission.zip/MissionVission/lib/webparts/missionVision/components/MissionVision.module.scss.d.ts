declare const styles: {
    missionVision: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=MissionVision.module.scss.d.ts.map

require("./MissionVision.module.css");
const styles = {
  missionVision: 'missionVision_8a85764f',
  teams: 'teams_8a85764f',
  welcome: 'welcome_8a85764f',
  welcomeImage: 'welcomeImage_8a85764f',
  links: 'links_8a85764f'
};

export default styles;
